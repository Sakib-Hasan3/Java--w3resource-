public class ex15 {
  
  public static void main(String[] args){
         System.out.format("\nCurrent Date time: %tc%n\n", System.currentTimeMillis());
    }
}
